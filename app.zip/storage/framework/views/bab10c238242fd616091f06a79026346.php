<p>Hello,</p>

<p>You have been invited to the meeting:</p>

<p><strong>Meeting Name:</strong> <?php echo e($meeting->meeting_name); ?></p>
<p><strong>Date:</strong> <?php echo e($meeting->date); ?></p>
<p><strong>Time:</strong> <?php echo e($meeting->start_time); ?> - <?php echo e($meeting->end_time); ?></p>

<?php if($meeting->meeting_type == 'virtual'): ?>
    <p><strong>Online Link:</strong> <a href="<?php echo e($meeting->online_link); ?>"><?php echo e($meeting->online_link); ?></a></p>
<?php else: ?>
    <p><strong>Location:</strong> <?php echo e($meeting->location); ?></p>
<?php endif; ?>

<p>Please be available on time.</p>

<p>Thank you.</p>
<?php /**PATH C:\Users\PC 2\Desktop\Works\Client\d\delta_it_2025\resources\views/emails/meeting_notification.blade.php ENDPATH**/ ?>