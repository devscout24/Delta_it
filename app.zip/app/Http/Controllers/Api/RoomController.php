<?php

namespace App\Http\Controllers\Api;

use App\Models\Room;
use App\Traits\ApiResponse;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RoomController extends Controller
{
    use ApiResponse;
    public function addRoom(Request $request)
    {
        $validated = $request->validate([
            'room_name' => 'required',
            'area' => 'required',
            'position' => 'nullable',
        ]);

        if (Room::where('room_name', $validated['room_name'])->exists()) {
            return $this->error(null, 'Room name already exists', 422);
        }

        if (Room::where('area', $validated['area'])->exists()) {
            return $this->error(null, 'Area already exists', 422);
        }

        if ($request->hasFile('position')) {
            $position = $this->uploadFile($request->file('position'), 'uploads/room_position', null);;
        }

        $room = Room::create([
            'room_name' => $request->room_name,
            'area' => $request->area,
            'position' => $position,
            'status' => 'available'
        ]);

        $room->position = asset($room->position);
        return $this->success($room, 'Room added successfully', 201);
    }
}
