<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContractFile extends Model
{
    protected $fillable = [
        'contract_id',
        'file_path',
    ];

    protected $hidden = ['created_at', 'updated_at'];

    public function getFileUrlAttribute()
    {
        return asset('uploads/contracts/files/' . $this->file_path);
    }
}
